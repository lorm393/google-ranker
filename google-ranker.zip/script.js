
document.getElementById('seoForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const url = document.getElementById('urlInput').value;
    const keyword = document.getElementById('keywordInput').value;
    const results = document.getElementById('results');
    
    results.innerHTML = `
        <h3>SEO Report for: ${url}</h3>
        <ul>
            <li>✅ Title tag should be under 60 characters.</li>
            <li>✅ Use the keyword "${keyword}" at least 1-2 times per 100 words.</li>
            <li>✅ Include the keyword in the H1 tag.</li>
            <li>✅ Add meta description under 160 characters.</li>
            <li>✅ Ensure mobile-friendly and fast loading.</li>
        </ul>
    `;
});
